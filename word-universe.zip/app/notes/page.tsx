"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { BookOpen, Search, Plus, Eye, Edit, Trash2, Star, Calendar, Filter } from "lucide-react"
import Link from "next/link"

interface Note {
  id: string
  name: string
  category: string
  language: string
  createdAt: string
  wordCount: number
  reviewedWords: number
  sentences: number
}

export default function NotesPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [selectedLanguage, setSelectedLanguage] = useState("all")

  // Mock data
  const notes: Note[] = [
    {
      id: "1",
      name: "AI 기술 뉴스",
      category: "기술",
      language: "en",
      createdAt: "2024-01-15",
      wordCount: 25,
      reviewedWords: 18,
      sentences: 8,
    },
    {
      id: "2",
      name: "프랑스 여행 가이드",
      category: "여행",
      language: "fr",
      createdAt: "2024-01-14",
      wordCount: 32,
      reviewedWords: 12,
      sentences: 12,
    },
    {
      id: "3",
      name: "비즈니스 이메일",
      category: "비즈니스",
      language: "en",
      createdAt: "2024-01-13",
      wordCount: 18,
      reviewedWords: 18,
      sentences: 6,
    },
  ]

  const categories = ["all", "기술", "여행", "비즈니스", "뉴스", "학술", "일반"]
  const languages = ["all", "en", "fr", "es", "de", "ja", "ko"]

  const getLanguageLabel = (lang: string) => {
    const labels: { [key: string]: string } = {
      en: "English",
      fr: "Français",
      es: "Español",
      de: "Deutsch",
      ja: "日本語",
      ko: "한국어",
    }
    return labels[lang] || lang
  }

  const getProgressPercentage = (reviewed: number, total: number) => {
    return Math.round((reviewed / total) * 100)
  }

  const filteredNotes = notes.filter((note) => {
    const matchesSearch = note.name.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === "all" || note.category === selectedCategory
    const matchesLanguage = selectedLanguage === "all" || note.language === selectedLanguage
    return matchesSearch && matchesCategory && matchesLanguage
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <Star className="w-8 h-8 text-indigo-600" />
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-purple-400 rounded-full animate-pulse" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                  마이노트
                </h1>
                <p className="text-sm text-muted-foreground">내가 만든 어휘 노트들</p>
              </div>
            </div>
            <Link href="/">
              <Button className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700">
                <Plus className="w-4 h-4 mr-2" />새 노트 만들기
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Filters */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Filter className="w-5 h-5" />
                필터 및 검색
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">검색</label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <Input
                      placeholder="노트 이름으로 검색..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">카테고리</label>
                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category === "all" ? "전체 카테고리" : category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">언어</label>
                  <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {languages.map((language) => (
                        <SelectItem key={language} value={language}>
                          {language === "all" ? "전체 언어" : getLanguageLabel(language)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Notes Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredNotes.map((note) => (
              <Card key={note.id} className="border-2 hover:border-indigo-200 transition-all hover:shadow-lg">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <CardTitle className="text-lg">{note.name}</CardTitle>
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary">{note.category}</Badge>
                        <Badge variant="outline">{getLanguageLabel(note.language)}</Badge>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Progress */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">복습 진행률</span>
                      <span className="font-medium">
                        {note.reviewedWords}/{note.wordCount} 단어
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-gradient-to-r from-indigo-500 to-purple-500 h-2 rounded-full transition-all"
                        style={{ width: `${getProgressPercentage(note.reviewedWords, note.wordCount)}%` }}
                      />
                    </div>
                    <p className="text-xs text-gray-500">
                      {getProgressPercentage(note.reviewedWords, note.wordCount)}% 완료
                    </p>
                  </div>

                  {/* Stats */}
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="text-center p-2 bg-gray-50 rounded">
                      <div className="font-semibold text-gray-900">{note.wordCount}</div>
                      <div className="text-gray-600">단어</div>
                    </div>
                    <div className="text-center p-2 bg-gray-50 rounded">
                      <div className="font-semibold text-gray-900">{note.sentences}</div>
                      <div className="text-gray-600">문장</div>
                    </div>
                  </div>

                  {/* Date */}
                  <div className="flex items-center gap-2 text-xs text-gray-500">
                    <Calendar className="w-3 h-3" />
                    {new Date(note.createdAt).toLocaleDateString("ko-KR")}
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2">
                    <Link href={`/notes/${note.id}`} className="flex-1">
                      <Button variant="outline" size="sm" className="w-full bg-transparent">
                        <Eye className="w-4 h-4 mr-2" />
                        보기
                      </Button>
                    </Link>
                    <Button variant="outline" size="sm">
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button variant="outline" size="sm" className="text-red-600 hover:text-red-700 bg-transparent">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredNotes.length === 0 && (
            <div className="text-center py-12">
              <BookOpen className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">노트가 없습니다</h3>
              <p className="text-gray-600 mb-4">새로운 노트를 만들어 단어 학습을 시작해보세요!</p>
              <Link href="/">
                <Button className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700">
                  <Plus className="w-4 h-4 mr-2" />첫 번째 노트 만들기
                </Button>
              </Link>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
