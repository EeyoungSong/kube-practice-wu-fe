"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, BookOpen, Star, Play, RotateCcw, Network } from "lucide-react"
import Link from "next/link"

interface Word {
  id: string
  word: string
  meaning: string
  partOfSpeech: string
  reviewLevel: number
  nextReview: string
  contexts: string[]
}

interface Sentence {
  id: string
  original: string
  translation: string
  words: string[]
}

export default function NoteDetailPage({ params }: { params: { id: string } }) {
  const [activeTab, setActiveTab] = useState("sentences")

  // Mock data
  const note = {
    id: params.id,
    name: "AI 기술 뉴스",
    category: "기술",
    language: "en",
    createdAt: "2024-01-15",
    wordCount: 25,
    reviewedWords: 18,
    sentences: 8,
  }

  const sentences: Sentence[] = [
    {
      id: "1",
      original: "The rapid advancement of artificial intelligence has transformed various industries.",
      translation: "인공지능의 급속한 발전은 다양한 산업을 변화시켰습니다.",
      words: ["rapid", "advancement", "artificial", "intelligence", "transformed", "industries"],
    },
    {
      id: "2",
      original: "Machine learning algorithms can process vast amounts of data efficiently.",
      translation: "머신러닝 알고리즘은 방대한 양의 데이터를 효율적으로 처리할 수 있습니다.",
      words: ["algorithms", "process", "vast", "efficiently"],
    },
  ]

  const words: Word[] = [
    {
      id: "w1",
      word: "rapid",
      meaning: "빠른, 신속한",
      partOfSpeech: "형용사",
      reviewLevel: 3,
      nextReview: "2024-01-20",
      contexts: ["The rapid advancement of artificial intelligence..."],
    },
    {
      id: "w2",
      word: "advancement",
      meaning: "발전, 진보",
      partOfSpeech: "명사",
      reviewLevel: 2,
      nextReview: "2024-01-18",
      contexts: ["The rapid advancement of artificial intelligence..."],
    },
    {
      id: "w3",
      word: "algorithms",
      meaning: "알고리즘",
      partOfSpeech: "명사",
      reviewLevel: 1,
      nextReview: "2024-01-16",
      contexts: ["Machine learning algorithms can process..."],
    },
  ]

  const getReviewLevelColor = (level: number) => {
    switch (level) {
      case 1:
        return "bg-red-100 text-red-700"
      case 2:
        return "bg-yellow-100 text-yellow-700"
      case 3:
        return "bg-green-100 text-green-700"
      default:
        return "bg-gray-100 text-gray-700"
    }
  }

  const getReviewLevelText = (level: number) => {
    switch (level) {
      case 1:
        return "초급"
      case 2:
        return "중급"
      case 3:
        return "고급"
      default:
        return "미복습"
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/notes">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  노트 목록
                </Button>
              </Link>
              <div>
                <h1 className="text-xl font-bold text-gray-900">{note.name}</h1>
                <div className="flex items-center gap-2">
                  <Badge variant="secondary">{note.category}</Badge>
                  <Badge variant="outline">English</Badge>
                  <span className="text-sm text-muted-foreground">
                    {new Date(note.createdAt).toLocaleDateString("ko-KR")}
                  </span>
                </div>
              </div>
            </div>
            <div className="flex gap-2">
              <Link href={`/constellation/${note.id}`}>
                <Button variant="outline">
                  <Network className="w-4 h-4 mr-2" />
                  별자리 보기
                </Button>
              </Link>
              <Link href={`/review/${note.id}`}>
                <Button className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700">
                  <Play className="w-4 h-4 mr-2" />
                  복습하기
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Stats Cards */}
          <div className="grid md:grid-cols-4 gap-4 mb-8">
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-indigo-600">{note.wordCount}</div>
                <div className="text-sm text-gray-600">총 단어</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-green-600">{note.reviewedWords}</div>
                <div className="text-sm text-gray-600">복습된 단어</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-purple-600">{note.sentences}</div>
                <div className="text-sm text-gray-600">문장 수</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-orange-600">
                  {Math.round((note.reviewedWords / note.wordCount) * 100)}%
                </div>
                <div className="text-sm text-gray-600">진행률</div>
              </CardContent>
            </Card>
          </div>

          {/* Content Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="sentences" className="flex items-center gap-2">
                <BookOpen className="w-4 h-4" />
                문장 목록
              </TabsTrigger>
              <TabsTrigger value="words" className="flex items-center gap-2">
                <Star className="w-4 h-4" />
                단어 목록
              </TabsTrigger>
            </TabsList>

            <TabsContent value="sentences" className="space-y-4">
              {sentences.map((sentence) => (
                <Card key={sentence.id} className="border-2 hover:border-indigo-200 transition-colors">
                  <CardHeader>
                    <div className="space-y-2">
                      <p className="text-lg font-medium text-gray-900">{sentence.original}</p>
                      <p className="text-gray-600">{sentence.translation}</p>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <h4 className="font-medium text-gray-900">포함된 단어:</h4>
                      <div className="flex flex-wrap gap-2">
                        {sentence.words.map((word) => (
                          <Badge key={word} variant="outline" className="cursor-pointer hover:bg-indigo-50">
                            {word}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="words" className="space-y-4">
              <div className="grid gap-4">
                {words.map((word) => (
                  <Card key={word.id} className="border-2 hover:border-indigo-200 transition-colors">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="space-y-2">
                          <div className="flex items-center gap-3">
                            <h3 className="text-lg font-semibold text-gray-900">{word.word}</h3>
                            <Badge variant="outline">{word.partOfSpeech}</Badge>
                            <Badge className={getReviewLevelColor(word.reviewLevel)}>
                              {getReviewLevelText(word.reviewLevel)}
                            </Badge>
                          </div>
                          <p className="text-gray-600">{word.meaning}</p>
                          <div className="space-y-1">
                            <p className="text-sm font-medium text-gray-700">사용 문맥:</p>
                            {word.contexts.map((context, index) => (
                              <p key={index} className="text-sm text-gray-600 italic">
                                "{context.substring(0, 80)}..."
                              </p>
                            ))}
                          </div>
                        </div>
                        <div className="text-right space-y-2">
                          <p className="text-xs text-gray-500">다음 복습</p>
                          <p className="text-sm font-medium">{new Date(word.nextReview).toLocaleDateString("ko-KR")}</p>
                          <Button size="sm" variant="outline">
                            <RotateCcw className="w-3 h-3 mr-1" />
                            복습
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
