"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, BookOpen, Check, Star } from "lucide-react"
import Link from "next/link"

interface Word {
  id: string
  word: string
  meaning: string
  partOfSpeech: string
  isSelected: boolean
  isKnown?: boolean
  previousContexts?: string[]
}

interface Sentence {
  id: string
  original: string
  translation: string
  words: Word[]
}

export default function AnalyzePage() {
  const searchParams = useSearchParams()
  const language = searchParams.get("lang") || "en"
  const inputType = searchParams.get("type") || "text"
  const noteName = searchParams.get("name") || ""
  const category = searchParams.get("category") || "일반"
  const content = searchParams.get("content") || ""

  const [sentences, setSentences] = useState<Sentence[]>([])
  const [isAnalyzing, setIsAnalyzing] = useState(true)

  // Mock data for demonstration
  useEffect(() => {
    const mockAnalyze = () => {
      setTimeout(() => {
        const mockSentences: Sentence[] = [
          {
            id: "1",
            original: "The rapid advancement of artificial intelligence has transformed various industries.",
            translation: "인공지능의 급속한 발전은 다양한 산업을 변화시켰습니다.",
            words: [
              {
                id: "w1",
                word: "rapid",
                meaning: "빠른, 신속한",
                partOfSpeech: "형용사",
                isSelected: false,
              },
              {
                id: "w2",
                word: "advancement",
                meaning: "발전, 진보",
                partOfSpeech: "명사",
                isSelected: false,
              },
              {
                id: "w3",
                word: "artificial",
                meaning: "인공의",
                partOfSpeech: "형용사",
                isSelected: false,
              },
              {
                id: "w4",
                word: "intelligence",
                meaning: "지능, 정보",
                partOfSpeech: "명사",
                isSelected: false,
              },
              {
                id: "w5",
                word: "transformed",
                meaning: "변화시키다",
                partOfSpeech: "동사",
                isSelected: false,
              },
              {
                id: "w6",
                word: "industries",
                meaning: "산업들",
                partOfSpeech: "명사",
                isSelected: false,
              },
            ],
          },
          {
            id: "2",
            original: "Machine learning algorithms can process vast amounts of data efficiently.",
            translation: "머신러닝 알고리즘은 방대한 양의 데이터를 효율적으로 처리할 수 있습니다.",
            words: [
              {
                id: "w7",
                word: "algorithms",
                meaning: "알고리즘",
                partOfSpeech: "명사",
                isSelected: false,
              },
              {
                id: "w8",
                word: "process",
                meaning: "처리하다",
                partOfSpeech: "동사",
                isSelected: false,
              },
              {
                id: "w9",
                word: "vast",
                meaning: "방대한, 광대한",
                partOfSpeech: "형용사",
                isSelected: false,
              },
              {
                id: "w10",
                word: "efficiently",
                meaning: "효율적으로",
                partOfSpeech: "부사",
                isSelected: false,
              },
            ],
          },
        ]
        setSentences(mockSentences)
        setIsAnalyzing(false)
      }, 2000)
    }

    mockAnalyze()
  }, [])

  const toggleWordSelection = (sentenceId: string, wordId: string) => {
    setSentences((prev) =>
      prev.map((sentence) =>
        sentence.id === sentenceId
          ? {
              ...sentence,
              words: sentence.words.map((word) =>
                word.id === wordId ? { ...word, isSelected: !word.isSelected } : word,
              ),
            }
          : sentence,
      ),
    )
  }

  const getSelectedWordsCount = () => {
    return sentences.reduce((total, sentence) => total + sentence.words.filter((word) => word.isSelected).length, 0)
  }

  const handleSaveToNote = () => {
    const selectedWords = sentences.flatMap((sentence) => sentence.words.filter((word) => word.isSelected))

    if (selectedWords.length > 0) {
      // Save to notes and redirect to notes page
      window.location.href = "/notes"
    }
  }

  if (isAnalyzing) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="p-8 text-center">
            <div className="animate-spin w-8 h-8 border-4 border-indigo-600 border-t-transparent rounded-full mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">문장을 분석하고 있습니다</h3>
            <p className="text-sm text-gray-600">AI가 텍스트에서 핵심 단어를 추출하고 있어요...</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/input">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  돌아가기
                </Button>
              </Link>
              <div>
                <h1 className="text-xl font-bold text-gray-900">{noteName}</h1>
                <p className="text-sm text-muted-foreground">
                  {category} • {language.toUpperCase()}
                </p>
              </div>
            </div>
            <Badge variant="secondary" className="bg-indigo-100 text-indigo-700">
              {getSelectedWordsCount()}개 단어 선택됨
            </Badge>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">문장 및 단어 추출 결과</h2>
            <p className="text-gray-600">학습하고 싶은 단어를 선택하세요. 이미 알고 있는 단어는 건너뛸 수 있습니다.</p>
          </div>

          <div className="space-y-6">
            {sentences.map((sentence) => (
              <Card key={sentence.id} className="border-2 hover:border-indigo-200 transition-colors">
                <CardHeader>
                  <div className="space-y-2">
                    <p className="text-lg font-medium text-gray-900">{sentence.original}</p>
                    <p className="text-gray-600">{sentence.translation}</p>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <h4 className="font-medium text-gray-900 flex items-center gap-2">
                      <BookOpen className="w-4 h-4" />
                      추출된 단어들
                    </h4>
                    <div className="grid gap-3">
                      {sentence.words.map((word) => (
                        <div
                          key={word.id}
                          className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                            word.isSelected
                              ? "border-indigo-500 bg-indigo-50"
                              : "border-gray-200 hover:border-indigo-300"
                          }`}
                          onClick={() => toggleWordSelection(sentence.id, word.id)}
                        >
                          <div className="flex items-start gap-3">
                            <Checkbox
                              checked={word.isSelected}
                              onChange={() => toggleWordSelection(sentence.id, word.id)}
                              className="mt-1"
                            />
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="font-semibold text-gray-900">{word.word}</span>
                                <Badge variant="outline" className="text-xs">
                                  {word.partOfSpeech}
                                </Badge>
                                {word.isKnown && (
                                  <Badge variant="secondary" className="text-xs bg-green-100 text-green-700">
                                    <Check className="w-3 h-3 mr-1" />
                                    학습됨
                                  </Badge>
                                )}
                              </div>
                              <p className="text-gray-600">{word.meaning}</p>
                              {word.previousContexts && word.previousContexts.length > 0 && (
                                <div className="mt-2 p-2 bg-yellow-50 rounded border-l-4 border-yellow-400">
                                  <p className="text-xs text-yellow-700 font-medium mb-1">이전에 학습한 단어입니다</p>
                                  <p className="text-xs text-yellow-600">"{word.previousContexts[0]}"</p>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Save Button */}
          <div className="mt-8 text-center">
            <Button
              onClick={handleSaveToNote}
              disabled={getSelectedWordsCount() === 0}
              size="lg"
              className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 px-8"
            >
              <Star className="w-4 h-4 mr-2" />
              노트에 저장하기 ({getSelectedWordsCount()}개 단어)
            </Button>
          </div>
        </div>
      </main>
    </div>
  )
}
