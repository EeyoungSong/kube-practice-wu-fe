"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Camera, FileText, Youtube, ArrowRight, Globe, BookOpen, Star } from "lucide-react"

export default function HomePage() {
  const [selectedLanguage, setSelectedLanguage] = useState("")
  const [selectedInputType, setSelectedInputType] = useState("")

  const languages = [
    { value: "en", label: "English" },
    { value: "fr", label: "Français" },
    { value: "es", label: "Español" },
    { value: "de", label: "Deutsch" },
    { value: "ja", label: "日本語" },
    { value: "ko", label: "한국어" },
  ]

  const inputTypes = [
    {
      value: "image",
      label: "이미지 업로드",
      icon: Camera,
      description: "사진이나 스크린샷에서 텍스트를 추출합니다",
    },
    {
      value: "text",
      label: "텍스트 입력",
      icon: FileText,
      description: "직접 텍스트를 입력하여 단어를 학습합니다",
    },
    {
      value: "youtube",
      label: "YouTube 링크",
      icon: Youtube,
      description: "YouTube 영상의 자막에서 단어를 추출합니다",
    },
  ]

  const handleNext = () => {
    if (selectedLanguage && selectedInputType) {
      window.location.href = `/input?lang=${selectedLanguage}&type=${selectedInputType}`
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="relative">
              <Star className="w-8 h-8 text-indigo-600" />
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-purple-400 rounded-full animate-pulse" />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                단어의 우주
              </h1>
              <p className="text-sm text-muted-foreground">별자리형 어휘장</p>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          {/* Welcome Section */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 bg-indigo-100 text-indigo-700 px-4 py-2 rounded-full text-sm font-medium mb-6">
              <Globe className="w-4 h-4" />
              언어 학습의 새로운 경험
            </div>
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              단어들이 연결되는 <span className="text-indigo-600">별자리</span>를 만들어보세요
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              이미지, 텍스트, 영상에서 단어를 추출하고 맥락 속에서 복습하며 단어 간의 연결을 시각화합니다
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Language Selection */}
            <Card className="border-2 hover:border-indigo-200 transition-colors">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-indigo-600" />
                  학습할 언어 선택
                </CardTitle>
                <CardDescription>어떤 언어를 학습하시겠습니까?</CardDescription>
              </CardHeader>
              <CardContent>
                <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                  <SelectTrigger className="w-full h-12">
                    <SelectValue placeholder="언어를 선택하세요" />
                  </SelectTrigger>
                  <SelectContent>
                    {languages.map((lang) => (
                      <SelectItem key={lang.value} value={lang.value}>
                        {lang.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </CardContent>
            </Card>

            {/* Input Type Selection */}
            <Card className="border-2 hover:border-purple-200 transition-colors">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Camera className="w-5 h-5 text-purple-600" />
                  입력 방식 선택
                </CardTitle>
                <CardDescription>어떤 방식으로 콘텐츠를 입력하시겠습니까?</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {inputTypes.map((type) => {
                  const Icon = type.icon
                  return (
                    <div
                      key={type.value}
                      className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                        selectedInputType === type.value
                          ? "border-purple-500 bg-purple-50"
                          : "border-gray-200 hover:border-purple-300"
                      }`}
                      onClick={() => setSelectedInputType(type.value)}
                    >
                      <div className="flex items-start gap-3">
                        <Icon
                          className={`w-5 h-5 mt-0.5 ${
                            selectedInputType === type.value ? "text-purple-600" : "text-gray-500"
                          }`}
                        />
                        <div>
                          <div
                            className={`font-medium ${
                              selectedInputType === type.value ? "text-purple-900" : "text-gray-900"
                            }`}
                          >
                            {type.label}
                          </div>
                          <div className="text-sm text-gray-600 mt-1">{type.description}</div>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </CardContent>
            </Card>
          </div>

          {/* Next Button */}
          <div className="text-center mt-12">
            <Button
              onClick={handleNext}
              disabled={!selectedLanguage || !selectedInputType}
              size="lg"
              className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white px-8 py-3 text-lg"
            >
              다음으로
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </div>

          {/* Features Preview */}
          <div className="mt-16 grid md:grid-cols-3 gap-6">
            <div className="text-center p-6">
              <div className="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Camera className="w-6 h-6 text-indigo-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">스마트 추출</h3>
              <p className="text-sm text-gray-600">AI가 이미지와 텍스트에서 핵심 단어를 자동으로 추출합니다</p>
            </div>
            <div className="text-center p-6">
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">별자리 연결</h3>
              <p className="text-sm text-gray-600">단어들 간의 관계를 별자리처럼 시각화하여 기억을 강화합니다</p>
            </div>
            <div className="text-center p-6">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <BookOpen className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">맞춤 복습</h3>
              <p className="text-sm text-gray-600">간격 반복 학습법으로 효과적인 단어 암기를 도와줍니다</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
