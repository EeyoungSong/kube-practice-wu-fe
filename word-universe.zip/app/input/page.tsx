"use client"

import type React from "react"

import { useState, useRef } from "react"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Camera, FileText, Youtube, Upload, ArrowLeft, Sparkles } from "lucide-react"
import Link from "next/link"

export default function InputPage() {
  const searchParams = useSearchParams()
  const language = searchParams.get("lang") || "en"
  const inputType = searchParams.get("type") || "text"

  const [noteName, setNoteName] = useState("")
  const [category, setCategory] = useState("")
  const [textContent, setTextContent] = useState("")
  const [youtubeUrl, setYoutubeUrl] = useState("")
  const [uploadedImage, setUploadedImage] = useState<File | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const categories = ["일반", "뉴스", "소설", "학술", "비즈니스", "여행", "요리", "기술", "예술", "스포츠"]

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      setUploadedImage(file)
    }
  }

  const handleAnalyze = () => {
    // 분석 페이지로 이동
    const params = new URLSearchParams({
      lang: language,
      type: inputType,
      name: noteName,
      category: category || "일반",
    })

    if (inputType === "text" && textContent) {
      params.set("content", textContent)
    } else if (inputType === "youtube" && youtubeUrl) {
      params.set("url", youtubeUrl)
    }

    window.location.href = `/analyze?${params.toString()}`
  }

  const getInputTypeInfo = () => {
    switch (inputType) {
      case "image":
        return { icon: Camera, title: "이미지 업로드", description: "이미지에서 텍스트를 추출합니다" }
      case "youtube":
        return { icon: Youtube, title: "YouTube 링크", description: "영상 자막에서 텍스트를 추출합니다" }
      default:
        return { icon: FileText, title: "텍스트 입력", description: "직접 텍스트를 입력합니다" }
    }
  }

  const { icon: Icon, title, description } = getInputTypeInfo()

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                돌아가기
              </Button>
            </Link>
            <div className="flex items-center gap-3">
              <Icon className="w-6 h-6 text-indigo-600" />
              <div>
                <h1 className="text-xl font-bold text-gray-900">{title}</h1>
                <p className="text-sm text-muted-foreground">{description}</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-purple-600" />
                콘텐츠 입력
              </CardTitle>
              <CardDescription>학습할 콘텐츠를 입력하고 노트 정보를 설정하세요</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Note Information */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="noteName">노트 이름</Label>
                  <Input
                    id="noteName"
                    placeholder="예: 영어 뉴스 기사"
                    value={noteName}
                    onChange={(e) => setNoteName(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="category">카테고리</Label>
                  <Select value={category} onValueChange={setCategory}>
                    <SelectTrigger>
                      <SelectValue placeholder="카테고리 선택" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((cat) => (
                        <SelectItem key={cat} value={cat}>
                          {cat}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Content Input */}
              {inputType === "text" && (
                <div className="space-y-2">
                  <Label htmlFor="textContent">텍스트 내용</Label>
                  <Textarea
                    id="textContent"
                    placeholder="학습할 텍스트를 입력하세요..."
                    className="min-h-[200px]"
                    value={textContent}
                    onChange={(e) => setTextContent(e.target.value)}
                  />
                </div>
              )}

              {inputType === "image" && (
                <div className="space-y-2">
                  <Label>이미지 업로드</Label>
                  <div
                    className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:border-indigo-400 transition-colors"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    {uploadedImage ? (
                      <div>
                        <Upload className="w-8 h-8 text-green-600 mx-auto mb-2" />
                        <p className="text-sm font-medium text-green-700">{uploadedImage.name}</p>
                        <p className="text-xs text-gray-500 mt-1">클릭하여 다른 이미지 선택</p>
                      </div>
                    ) : (
                      <div>
                        <Camera className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                        <p className="text-sm text-gray-600">클릭하여 이미지를 업로드하세요</p>
                        <p className="text-xs text-gray-500 mt-1">JPG, PNG, GIF 파일 지원</p>
                      </div>
                    )}
                  </div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </div>
              )}

              {inputType === "youtube" && (
                <div className="space-y-2">
                  <Label htmlFor="youtubeUrl">YouTube URL</Label>
                  <Input
                    id="youtubeUrl"
                    placeholder="https://www.youtube.com/watch?v=..."
                    value={youtubeUrl}
                    onChange={(e) => setYoutubeUrl(e.target.value)}
                  />
                  <p className="text-xs text-gray-500">자막이 있는 YouTube 영상의 링크를 입력하세요</p>
                </div>
              )}

              {/* Action Button */}
              <Button
                onClick={handleAnalyze}
                disabled={
                  !noteName ||
                  (inputType === "text" && !textContent) ||
                  (inputType === "image" && !uploadedImage) ||
                  (inputType === "youtube" && !youtubeUrl)
                }
                className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                size="lg"
              >
                <Sparkles className="w-4 h-4 mr-2" />
                문장 분석하기
              </Button>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
