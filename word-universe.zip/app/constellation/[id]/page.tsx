"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, ZoomIn, ZoomOut, RotateCcw, Info } from "lucide-react"
import Link from "next/link"

interface Node {
  id: string
  label: string
  type: "word" | "sentence" | "note"
  x: number
  y: number
  connections: string[]
  data?: any
}

export default function ConstellationPage({ params }: { params: { id: string } }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [selectedNode, setSelectedNode] = useState<Node | null>(null)
  const [zoom, setZoom] = useState(1)
  const [pan, setPan] = useState({ x: 0, y: 0 })

  // Mock constellation data
  const nodes: Node[] = [
    {
      id: "w1",
      label: "rapid",
      type: "word",
      x: 200,
      y: 150,
      connections: ["s1", "w2"],
      data: { meaning: "빠른, 신속한", partOfSpeech: "형용사" },
    },
    {
      id: "w2",
      label: "advancement",
      type: "word",
      x: 350,
      y: 200,
      connections: ["s1", "w3"],
      data: { meaning: "발전, 진보", partOfSpeech: "명사" },
    },
    {
      id: "w3",
      label: "artificial",
      type: "word",
      x: 500,
      y: 150,
      connections: ["s1", "w4"],
      data: { meaning: "인공의", partOfSpeech: "형용사" },
    },
    {
      id: "w4",
      label: "intelligence",
      type: "word",
      x: 650,
      y: 200,
      connections: ["s1", "s2"],
      data: { meaning: "지능, 정보", partOfSpeech: "명사" },
    },
    {
      id: "s1",
      label: "AI 문장 1",
      type: "sentence",
      x: 400,
      y: 100,
      connections: ["w1", "w2", "w3", "w4"],
      data: { text: "The rapid advancement of artificial intelligence..." },
    },
    {
      id: "s2",
      label: "AI 문장 2",
      type: "sentence",
      x: 600,
      y: 300,
      connections: ["w4", "w5"],
      data: { text: "Machine learning algorithms can process..." },
    },
    {
      id: "w5",
      label: "algorithms",
      type: "word",
      x: 750,
      y: 350,
      connections: ["s2"],
      data: { meaning: "알고리즘", partOfSpeech: "명사" },
    },
  ]

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas size
    canvas.width = canvas.offsetWidth
    canvas.height = canvas.offsetHeight

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Apply zoom and pan
    ctx.save()
    ctx.scale(zoom, zoom)
    ctx.translate(pan.x, pan.y)

    // Draw connections first
    ctx.strokeStyle = "#e5e7eb"
    ctx.lineWidth = 2
    nodes.forEach((node) => {
      node.connections.forEach((connectionId) => {
        const connectedNode = nodes.find((n) => n.id === connectionId)
        if (connectedNode) {
          ctx.beginPath()
          ctx.moveTo(node.x, node.y)
          ctx.lineTo(connectedNode.x, connectedNode.y)
          ctx.stroke()
        }
      })
    })

    // Draw nodes
    nodes.forEach((node) => {
      const isSelected = selectedNode?.id === node.id

      // Node circle
      ctx.beginPath()
      ctx.arc(node.x, node.y, isSelected ? 25 : 20, 0, 2 * Math.PI)

      if (node.type === "word") {
        ctx.fillStyle = isSelected ? "#4f46e5" : "#6366f1"
      } else if (node.type === "sentence") {
        ctx.fillStyle = isSelected ? "#7c3aed" : "#8b5cf6"
      } else {
        ctx.fillStyle = isSelected ? "#059669" : "#10b981"
      }

      ctx.fill()

      // Node border
      ctx.strokeStyle = "#ffffff"
      ctx.lineWidth = 3
      ctx.stroke()

      // Node label
      ctx.fillStyle = "#ffffff"
      ctx.font = isSelected ? "bold 12px sans-serif" : "11px sans-serif"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(node.label, node.x, node.y)

      // Glow effect for selected node
      if (isSelected) {
        ctx.shadowColor = node.type === "word" ? "#4f46e5" : "#7c3aed"
        ctx.shadowBlur = 20
        ctx.beginPath()
        ctx.arc(node.x, node.y, 25, 0, 2 * Math.PI)
        ctx.stroke()
        ctx.shadowBlur = 0
      }
    })

    ctx.restore()
  }, [nodes, selectedNode, zoom, pan])

  const handleCanvasClick = (event: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current
    if (!canvas) return

    const rect = canvas.getBoundingClientRect()
    const x = (event.clientX - rect.left - pan.x * zoom) / zoom
    const y = (event.clientY - rect.top - pan.y * zoom) / zoom

    // Find clicked node
    const clickedNode = nodes.find((node) => {
      const distance = Math.sqrt((x - node.x) ** 2 + (y - node.y) ** 2)
      return distance <= 25
    })

    setSelectedNode(clickedNode || null)
  }

  const handleZoomIn = () => {
    setZoom((prev) => Math.min(prev * 1.2, 3))
  }

  const handleZoomOut = () => {
    setZoom((prev) => Math.max(prev / 1.2, 0.5))
  }

  const handleReset = () => {
    setZoom(1)
    setPan({ x: 0, y: 0 })
    setSelectedNode(null)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href={`/notes/${params.id}`}>
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  노트로 돌아가기
                </Button>
              </Link>
              <div>
                <h1 className="text-xl font-bold text-gray-900">단어 별자리</h1>
                <p className="text-sm text-muted-foreground">단어와 문장의 연결 관계를 시각화</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={handleZoomIn}>
                <ZoomIn className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="sm" onClick={handleZoomOut}>
                <ZoomOut className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="sm" onClick={handleReset}>
                <RotateCcw className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-4 gap-6 h-[calc(100vh-200px)]">
          {/* Constellation Canvas */}
          <div className="lg:col-span-3">
            <Card className="h-full">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-indigo-500 rounded-full" />
                  단어 별자리
                </CardTitle>
                <CardDescription>노드를 클릭하여 상세 정보를 확인하세요</CardDescription>
              </CardHeader>
              <CardContent className="p-0 h-[calc(100%-80px)]">
                <canvas
                  ref={canvasRef}
                  onClick={handleCanvasClick}
                  className="w-full h-full cursor-pointer"
                  style={{ background: "linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%)" }}
                />
              </CardContent>
            </Card>
          </div>

          {/* Info Panel */}
          <div className="space-y-4">
            {/* Legend */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">범례</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-4 h-4 bg-indigo-500 rounded-full" />
                  <span className="text-sm">단어</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-4 h-4 bg-purple-500 rounded-full" />
                  <span className="text-sm">문장</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-4 h-4 bg-green-500 rounded-full" />
                  <span className="text-sm">노트</span>
                </div>
              </CardContent>
            </Card>

            {/* Selected Node Info */}
            {selectedNode ? (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Info className="w-4 h-4" />
                    상세 정보
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <Badge variant={selectedNode.type === "word" ? "default" : "secondary"}>
                      {selectedNode.type === "word" ? "단어" : "문장"}
                    </Badge>
                    <h3 className="font-semibold text-lg mt-2">{selectedNode.label}</h3>
                  </div>

                  {selectedNode.type === "word" && selectedNode.data && (
                    <div className="space-y-2">
                      <p className="text-gray-600">{selectedNode.data.meaning}</p>
                      <Badge variant="outline">{selectedNode.data.partOfSpeech}</Badge>
                    </div>
                  )}

                  {selectedNode.type === "sentence" && selectedNode.data && (
                    <div>
                      <p className="text-sm text-gray-600 italic">"{selectedNode.data.text}"</p>
                    </div>
                  )}

                  <div>
                    <p className="text-sm font-medium text-gray-700 mb-2">
                      연결된 요소 ({selectedNode.connections.length}개)
                    </p>
                    <div className="space-y-1">
                      {selectedNode.connections.map((connectionId) => {
                        const connectedNode = nodes.find((n) => n.id === connectionId)
                        return connectedNode ? (
                          <div key={connectionId} className="flex items-center gap-2">
                            <div
                              className={`w-2 h-2 rounded-full ${
                                connectedNode.type === "word" ? "bg-indigo-500" : "bg-purple-500"
                              }`}
                            />
                            <span className="text-sm">{connectedNode.label}</span>
                          </div>
                        ) : null
                      })}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="p-6 text-center">
                  <Info className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-600">노드를 클릭하여 상세 정보를 확인하세요</p>
                </CardContent>
              </Card>
            )}

            {/* Controls */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">조작법</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm text-gray-600">
                <p>• 노드 클릭: 상세 정보 보기</p>
                <p>• 확대/축소: 상단 버튼 사용</p>
                <p>• 초기화: 리셋 버튼 클릭</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
